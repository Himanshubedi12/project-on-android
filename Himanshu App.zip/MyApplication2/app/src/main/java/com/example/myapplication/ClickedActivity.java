package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.net.URL;

import retrofit2.http.GET;

public class ClickedActivity extends AppCompatActivity {
ImagesResponse imagesResponse;
TextView Name;
ImageView imageView;
TextView term;
TextView disc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicked);
        Name = findViewById(R.id.selectedName);
        imageView = findViewById(R.id.selectedImage);
        term = findViewById(R.id.selectedTerm);
        disc = findViewById(R.id.selecteddisc);


        Intent intent = new Intent();
        if (intent.getExtras() != null){
            imagesResponse = (ImagesResponse)intent.getSerializableExtra("data");
         Name.setText(imagesResponse.getName());
            GlideApp.with(this).load(imagesResponse.getUrl()).into(imageView);

        }

    }
}
